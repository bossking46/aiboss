import React from "react";

const stats = () => {
  return <div>stats</div>;
};

export default stats;
