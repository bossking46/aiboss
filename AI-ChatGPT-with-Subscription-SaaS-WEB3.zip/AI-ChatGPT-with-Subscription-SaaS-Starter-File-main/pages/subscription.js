import React from "react";

const subscription = () => {
  return <div>subscription</div>;
};

export default subscription;
