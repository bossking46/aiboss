import React from "react";

const openai = () => {
  return <div>openai</div>;
};

export default openai;
