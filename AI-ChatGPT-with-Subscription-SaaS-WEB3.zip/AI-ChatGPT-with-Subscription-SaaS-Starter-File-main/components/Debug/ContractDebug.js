import React from "react";

const ContractDebug = () => {
  return <div>ContractDebug</div>;
};

export default ContractDebug;
