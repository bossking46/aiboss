import React from "react";

const ConnectWallet = () => {
  return <div>ConnectWallet</div>;
};

export default ConnectWallet;
