import React from "react";

const MessageFormatter = () => {
  return <div>MessageFormatter</div>;
};

export default MessageFormatter;
